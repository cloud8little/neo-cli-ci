dotnet neo-cli.dll /rpc
